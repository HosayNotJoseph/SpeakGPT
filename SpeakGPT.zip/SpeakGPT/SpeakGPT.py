import random
import tts
import time
import loading
from termcolor import colored


print(colored('COLOR TEST', 'red'))
print(colored('IF NOT COLORED, SEE README.MD!', 'yellow'))

time.sleep(5)

loading.load()

# Load the training data from a text file
def load_training_data(file_path):
    training_data = {}
    with open(file_path, 'r') as file:
        lines = file.readlines()
        for line in lines:
            line = line.strip()
            if line:
                input_text, output_text = line.split('>>')
                input_text = input_text.strip()
                output_text = output_text.strip()
                if input_text in training_data:
                    training_data[input_text].append(output_text)
                else:
                    training_data[input_text] = [output_text]
    return training_data

# Save the training data to a text file
def save_training_data(file_path, training_data):
    with open(file_path, 'w') as file:
        for input_text, output_texts in training_data.items():
            for output_text in output_texts:
                file.write(f"{input_text}>>{output_text}\n")

# Generate a response from the chatbot
def generate_response(user_input, training_data):
    if user_input.lower() in training_data:
        possible_responses = training_data[user_input.lower()]
        return random.choice(possible_responses)
    return None

# Main function to run the chatbot
def run_chatbot(file_path):
    training_data = load_training_data(file_path)
    print(colored('Chatbot: ', 'red')+ colored('Hi, how can I assist you today?', 'green'))
    tts.TTS("Hi, how can I assist you today?")
    while True:
        user_input = input(colored('User: ', 'red'))
        if user_input.lower() == 'bye':
            print(colored('Chatbot: ', 'red') + (colored('Goodbye!', 'green')))
            tts.TTS("Goodbye!")
            break
        response = generate_response(user_input, training_data)
        if response is None:
            print((colored('Chatbot: ', 'red') + (colored('Im sorry, I dont know how to respond to that.', 'green'))))
            tts.TTS("I'm sorry, I don't know how to respond to that.")
            tts.TTS("Please provide the correct response: ")
            correct_response = input((colored('Chatbot: ', 'red')+ (colored('Please provide the correct responce: ', 'green'))))
            if user_input.lower() in training_data:
                training_data[user_input.lower()].append(correct_response)
            else:
                training_data[user_input.lower()] = [correct_response]
            save_training_data(file_path, training_data)
            print((colored('Chatbot: ', 'red') + (colored('Thank you for teaching me!', 'green'))))
            tts.TTS("Thank you for teaching me!")
        else:
            print((colored('Chatbot: ', 'red') + (colored(response, 'green'))))
            tts.TTS(response)

# Run the chatbot
file_path = 'training_data.txt'  # Replace with the path to your training data file
run_chatbot(file_path)
