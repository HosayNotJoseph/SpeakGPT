import time
from termcolor import colored

def load() :

    with open("Loadtext.txt", "r") as f:
        for line in f :
            print(colored(line, 'light_cyan'))
            time.sleep(0.1)

